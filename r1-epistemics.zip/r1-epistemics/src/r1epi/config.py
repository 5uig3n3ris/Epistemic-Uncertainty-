"""Model aliases, run-directory layout and shared CLI args (no torch import)."""
import pathlib

MODEL_ALIASES = {
    "tiny": "Qwen/Qwen2.5-0.5B-Instruct",                # laptop debugging (CPU, ~2 GB)
    "small": "deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B",  # laptop (slow) or any GPU
    "base": "deepseek-ai/DeepSeek-R1-Distill-Qwen-7B",     # Kaggle 2xT4 / 16 GB+ GPU
}
DEFAULT_MODEL = "tiny"


def resolve_model(name: str) -> str:
    return MODEL_ALIASES.get(name, name)


def run_dir(out: str, model: str, dataset: str) -> pathlib.Path:
    """results/<model-name>/<dataset>, so runs on different models never overwrite each other."""
    d = pathlib.Path(out) / resolve_model(model).split("/")[-1] / dataset
    d.mkdir(parents=True, exist_ok=True)
    return d


def add_model_args(ap):
    ap.add_argument("--model", default=DEFAULT_MODEL,
                    help=f"alias {list(MODEL_ALIASES)} or any HF model id")
    ap.add_argument("--dtype", default="auto", choices=["auto", "float32", "float16", "bfloat16"],
                    help="auto = float16 on GPU, float32 on CPU")
    ap.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    ap.add_argument("--8bit", dest="int8", action="store_true", help="8-bit weights (GPU only)")
    ap.add_argument("--out", default="results")
    return ap
