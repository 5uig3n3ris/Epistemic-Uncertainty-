"""Compare probe vs. baseline AUROC across every model that has results (the scaling story)."""
import argparse
import json
import pathlib

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="triviaqa")
    ap.add_argument("--out", default="results")
    a = ap.parse_args()

    rows = []
    for pm in sorted(pathlib.Path(a.out).glob(f"*/{a.dataset}/probe_metrics.json")):
        d = pm.parent
        probe = json.load(open(pm))
        bm = d / "baseline_metrics.json"
        base = json.load(open(bm)) if bm.exists() else {}
        rows.append((d.parent.name, max(probe["layer_auroc"]), base.get("auroc_semantic_entropy"),
                     base.get("auroc_token_entropy"), base.get("accuracy")))
    if not rows:
        raise SystemExit("No results found. Run scripts 01-03 first.")

    print(f"{'model':45s} probe   sem.ent  tok.ent  acc")
    f = lambda v: "  n/a " if v is None else f"{v:6.3f}"
    for r in rows:
        print(f"{r[0]:45s} {f(r[1])}  {f(r[2])}   {f(r[3])}  {f(r[4])}")

    x = np.arange(len(rows))
    plt.figure(figsize=(6, 3.5))
    for i, (lab, j) in enumerate([("probe (best layer)", 1), ("semantic entropy", 2), ("token entropy", 3)]):
        vals = [r[j] if r[j] is not None else 0 for r in rows]
        plt.bar(x + (i - 1) * 0.27, vals, 0.27, label=lab)
    plt.xticks(x, [r[0].replace("DeepSeek-R1-Distill-", "R1-") for r in rows], rotation=15, fontsize=7)
    plt.ylim(0.4, 1); plt.ylabel("AUROC (error detection)"); plt.legend(fontsize=7); plt.tight_layout()
    out = pathlib.Path(a.out) / f"scaling_{a.dataset}.png"
    plt.savefig(out, dpi=150)
    print("Saved", out)


if __name__ == "__main__":
    main()
