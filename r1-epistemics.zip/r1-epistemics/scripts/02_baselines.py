"""Black-box baselines: token entropy, semantic entropy, verbalized confidence."""
import argparse
import json

import numpy as np
from tqdm import tqdm

from r1epi import model as M
from r1epi.config import add_model_args, run_dir
from r1epi.calibration import auroc_error_detection, ece
from r1epi.uncertainty import (CONF_PROMPT, NLIClusterer, mean_token_entropy,
                               parse_confidence, semantic_entropy)


def main():
    ap = add_model_args(argparse.ArgumentParser())
    ap.add_argument("--dataset", default="triviaqa")
    ap.add_argument("--nli-device", default=None, help="cpu/cuda for the NLI clusterer (default: auto)")
    ap.add_argument("--k", type=int, default=10, help="samples for semantic entropy")
    ap.add_argument("--think", action="store_true")
    a = ap.parse_args()

    d = run_dir(a.out, a.model, a.dataset)
    recs = [json.loads(l) for l in open(d / "generations.jsonl")]
    tok, model = M.load(a.model, a.dtype, a.device, a.int8)
    nli = NLIClusterer(device=a.nli_device)

    rows = []
    for r in tqdm(recs):
        samples = M.sample_answers(model, tok, r["question"], k=a.k, think=a.think)
        se = semantic_entropy(nli.cluster(r["question"], samples))
        conf_txt = M.generate_text(model, tok, CONF_PROMPT.format(q=r["question"], a=r["answer"]), think=False)
        conf = parse_confidence(conf_txt)
        rows.append({
            "id": r["id"], "correct": r["correct"],
            "token_entropy": mean_token_entropy(r["entropies"], r["think_end_idx"]),
            "semantic_entropy": se,
            "verbalized_conf": conf if conf is not None else 0.5,
        })
    with open(d / "baselines.jsonl", "w") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")

    y = np.array([r["correct"] for r in rows])
    res = {
        "accuracy": float(y.mean()),
        "auroc_token_entropy": auroc_error_detection([r["token_entropy"] for r in rows], y),
        "auroc_semantic_entropy": auroc_error_detection([r["semantic_entropy"] for r in rows], y),
        "auroc_verbalized": auroc_error_detection([1 - r["verbalized_conf"] for r in rows], y),
        "ece_verbalized": ece([r["verbalized_conf"] for r in rows], y),
    }
    json.dump(res, open(d / "baseline_metrics.json", "w"), indent=2)
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
