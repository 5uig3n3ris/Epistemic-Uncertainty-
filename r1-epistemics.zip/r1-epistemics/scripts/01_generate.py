"""Generate greedy answers, label correctness, cache last-prompt-token hidden states."""
import argparse
import json

import numpy as np
from tqdm import tqdm

from r1epi import model as M
from r1epi.config import add_model_args, resolve_model, run_dir
from r1epi.data import load_qa
from r1epi.grading import is_correct


def main():
    ap = add_model_args(argparse.ArgumentParser())
    ap.add_argument("--dataset", default="triviaqa", choices=["triviaqa", "popqa"])
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--think", action="store_true", help="let R1-style models produce a <think> trace")
    ap.add_argument("--max-new-tokens", type=int, default=256)
    a = ap.parse_args()

    d = run_dir(a.out, a.model, a.dataset)
    tok, model = M.load(a.model, a.dtype, a.device, a.int8)
    rows = load_qa(a.dataset, a.n)
    json.dump({**vars(a), "model_id": resolve_model(a.model)}, open(d / "run_config.json", "w"), indent=2)

    hidden = []
    with open(d / "generations.jsonl", "w") as f:
        for r in tqdm(rows):
            g = M.generate_one(model, tok, r["question"], think=a.think, max_new_tokens=a.max_new_tokens)
            hidden.append(g.pop("hidden"))
            rec = {**r, **g, "correct": is_correct(g["answer"], r["answers"])}
            f.write(json.dumps(rec) + "\n")
    np.save(d / "hidden_last_prompt_token.npy", np.stack(hidden).astype(np.float16))
    print(f"Saved {len(rows)} generations to {d}")


if __name__ == "__main__":
    main()
